import java.util.ArrayList;
public abstract class AbstractMap {
int size = 0;
int capacity; 
private ArrayList<Element> bucketArray;

public int size() {
	return size;
}
public boolean isEmpty() {
	return size==0;
}
public int compress(Element e) {
	
	int hashcode = e.hashCode();
	int index = hashcode %capacity;
	return index;
}
}
