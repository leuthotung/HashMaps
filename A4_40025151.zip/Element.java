
public class Element {
	int key;
	Object value;
	public Element(int key, Object value) {
		this.key = key;
		this.value = value;
	}
	public int hashCode() {
		return key;
	}
	}

