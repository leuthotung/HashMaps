
public class LinearProbing extends AbstractMap{

}
