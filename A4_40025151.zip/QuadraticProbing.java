
public class QuadraticProbing extends AbstractMap{
	

}
